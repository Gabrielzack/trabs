<?php


//    var_dump($_POST);
//    exit();

    session_start();

function login(){

    $usuarios = file_get_contents("usuario.json");
    $usuarios = json_decode($usuarios, true);

    foreach ($usuarios as $usuario){

        if ($_POST['login'] == $usuario['usuario'] && $_POST['senha'] == 'senha') {

            $_SESSION['nome']  = $_POST['nome'];
            $_SESSION['login'] = $_POST['login'];
            $_SESSION['senha'] = $_POST['senha'];

            $_SESSION['esta_logado'] = true;


            //redireciona o usuario para index.php
            header('Location: index.php');

        } else {
            //deu ruim
            header('Location: login.php');
        }
    }

}


    function sair(){
    session_destroy();
    header('Location: login.php');
    }

    //ROTAS
    if($_POST['login_form'] == "acessar"){
        login();
    }

    if($_POST['login_form'] == "sair"){
    sair();
}